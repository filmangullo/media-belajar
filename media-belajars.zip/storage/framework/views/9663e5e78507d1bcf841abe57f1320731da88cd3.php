<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
    <div class="modal-dialog" role="document" >

    </div>
</div>
<?php /**PATH /var/www/media-belajar/resources/views/layouts/modal.blade.php ENDPATH**/ ?>