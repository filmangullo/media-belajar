<?php if($message = Session::get('primary')): ?>
<div class="alert alert-primary alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
   <a class="alert-link" href="#">Hello! </a> <?php echo e($message); ?>.
</div>

<?php elseif($message = Session::get('secondary')): ?>

<div class="alert alert-secondary alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
    <a class="alert-link" href="#">Hmmmm! </a><?php echo e($message); ?>.
</div>

<?php elseif($message = Session::get('success')): ?>

<div class="alert alert-success alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
    <a class="alert-link" href="#">Success! </a> <?php echo e($message); ?>.
</div>

<?php elseif($message = Session::get('errors')): ?>

<div class="alert alert-danger alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
   <a class="alert-link" href="#">Peringatan! </a> <?php echo e($message); ?>.
</div>

<?php elseif($message = Session::get('warning')): ?>

<div class="alert alert-warning alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
    <a class="alert-link" href="#">Perhatian! </a><?php echo e($message); ?>.
</div>

<?php elseif($message = Session::get('info')): ?>

<div class="alert alert-info alert-dismissable">
    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
    <a class="alert-link" href="#">Information!</a> <?php echo e($message); ?>.
</div>

<?php endif; ?>
<?php /**PATH /var/www/media-belajar/resources/views/layouts/alert.blade.php ENDPATH**/ ?>