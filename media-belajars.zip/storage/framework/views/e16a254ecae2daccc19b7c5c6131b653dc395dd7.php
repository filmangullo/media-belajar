<?php $__env->startSection('courses'); ?>

menu-active

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-white">
    Daftra Tugas <?php echo e($forum->kelasMataPelajarans['nama']); ?>

</h1>
<p><?php echo e($forum->nama); ?></p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.courses')); ?>">Courses</a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('show.courses', $forum->kelasMataPelajarans['id'] )); ?>"><?php echo e($forum->kelasMataPelajarans['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.pertemuan', $forum->id )); ?>"><?php echo e($forum['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.tugaspelajar', $forum->id )); ?>">Daftar Tugas</a>
    </span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Align Area -->
<div class="whole-wrap">
    <div class="container">
        <div class="section-top-border">

          <?php echo $tugasKumpul->tugas; ?>

        </div>
        <div class="section-top-border">
          <p><a href="<?php echo e(route('download.tugaspelajar', $tugasKumpul->id)); ?>"  ><i class="lnr lnr-download"></i>&nbsp;Download</a>&nbsp;
            Tugas : <?php echo e($tugasKumpul->users['name']); ?> &nbsp;</p>
        </div>
    </div>

    <div class="container">
    <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('nilai.tugaspelajar', $tugasKumpul->id)); ?>" method="post" >
            <?php echo e(csrf_field()); ?>

            <div class="input-group mb-3">
                <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Nilai &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                </div>
                <input type="number" class="form-control" placeholder="Nilai" aria-label="Nilai" name="nilai" aria-describedby="basic-addon1" value="<?php echo e($tugasKumpul->nilai); ?>" require>
            </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Catatan</span>
                </div>
                <textarea name="catatan_pengajar" id="catatan_pengajar" rows="10" class="form-control" placeholder="Catatan"  aria-label="Catatan"><?php echo $tugasKumpul->catatan_pengajar; ?></textarea>
            </div>

            <div class="modal-footer">
                
                <a href="<?php echo e(route('index.tugaspelajar', $tugasKumpul->forum_id )); ?>" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
        </form>
    </div>
</div>
<!-- End Align Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/tugas/tugas_pelajar_show.blade.php ENDPATH**/ ?>