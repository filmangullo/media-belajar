	<footer class="footer-area">
	    <div class="container">
	        <div class="footer-bottom row align-items-center col-md-12" style="text-align: center;">
	            <p style="margin-left: 23%">
	                Copyright &copy;<script>document.write(new Date().getFullYear());
	                </script> All rights reserved | Website by <a href="/" target="_blank">Faisal Faturrahman</a></p>
	        </div>
	    </div>
	</footer>

	<!-- ####################### Start Scroll to Top Area ####################### -->
	<div id="back-top">
	    <a title="Go to Top" href="#"></a>
	</div>
	<!-- ####################### End Scroll to Top Area ####################### -->
<?php /**PATH /var/www/media-belajar/resources/views/layouts/webFooter.blade.php ENDPATH**/ ?>