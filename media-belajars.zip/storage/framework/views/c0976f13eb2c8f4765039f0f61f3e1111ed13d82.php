<?php $__env->startSection('courses'); ?>

menu-active

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-white">
    Kuis <?php echo e($forum->kelasMataPelajarans['nama']); ?>

</h1>
<p><?php echo e($forum->nama); ?></p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.courses')); ?>">Courses</a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('show.courses', $forum->kelasMataPelajarans['id'] )); ?>"><?php echo e($forum->kelasMataPelajarans['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.pertemuan', $forum->id )); ?>"><?php echo e($forum['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.kuis', $forum->id )); ?>">Kerjakan Kuis</a>
    </span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Align Area -->
<div class="whole-wrap">
    <div class="container">
        <div class="section-top-border">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <center>
                <h3>Nilai Kuis : <?php echo e($nilai_kuis); ?></h3>
            </center>
            <?php if($display_soal == false): ?>
            <div class="text-center">
                <img src="<?php echo e(URL::asset('webs/img/semangat.gif')); ?>" alt="">
            </div>
            <?php endif; ?>

            <div <?php if( $display_soal == true ): ?> style="display:block" <?php else: ?> style="display:none" <?php endif; ?>>

                <h3 class="mb-30">Soal Kuis</h3>
                <form action="<?php echo e(route('index.calculateKuis', $forum->id )); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <?php $num = 0; ?>
                        <?php foreach ($kuis as $key => $soal): ?>
                        <div class="col-lg-12">
                            <blockquote class="generic-blockquote">
                                <input type="number" id="id_soal" name="soal_ke_[<?php echo e($key); ?>]" value="<?php echo e($soal->id); ?>"
                                    hidden>
                                <p> <?php echo e(++$num); ?>. <?php echo $soal->soal; ?></p>
                                <?php foreach ($soal->forumKuisImgs as $key => $img): ?>
                                      <img src="<?php echo e(asset('storage/'.$img->img)); ?>" alt="Girl in a jacket" width="50%">
                                <?php endforeach; ?>
                                <br />
                                <input type="radio" id="pilihan_a[<?php echo e($key); ?>]" name="jawaban_ke_[<?php echo e($key); ?>]" value="a">
                                <label for="pilihan_a[<?php echo e($key); ?>]"><?php echo $soal->pilihan_a; ?></label><br>

                                <input type="radio" id="pilihan_b[<?php echo e($key); ?>]" name="jawaban_ke_[<?php echo e($key); ?>]" value="b">
                                <label for="pilihan_b[<?php echo e($key); ?>]"><?php echo $soal->pilihan_b; ?></label><br>

                                <input type="radio" id="pilihan_c[<?php echo e($key); ?>]" name="jawaban_ke_[<?php echo e($key); ?>]" value="c">
                                <label for="pilihan_c[<?php echo e($key); ?>]"><?php echo $soal->pilihan_c; ?></label><br>

                                <input type="radio" id="pilihan_d[<?php echo e($key); ?>]" name="jawaban_ke_[<?php echo e($key); ?>]" value="d">
                                <label for="pilihan_d[<?php echo e($key); ?>]"><?php echo $soal->pilihan_d; ?></label><br>

                                <input type="radio" id="pilihan_e[<?php echo e($key); ?>]" name="jawaban_ke_[<?php echo e($key); ?>]" value="e">
                                <label for="pilihan_e[<?php echo e($key); ?>]"><?php echo $soal->pilihan_e; ?></label><br>
                                <!-- Terpilih otomatis jika tidak di jawab -->
                                <input type="radio" id="pilihan_a" name="jawaban_ke_[<?php echo e($key); ?>]" select hidden
                                    value="null">
                            </blockquote>
                        </div>
                        <?php endforeach; ?>
                        <div class="col-lg-12 text-center">
                            <button type="submit" class="genric-btn success">Selesai Kuis..!</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- End Align Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/kuis/kuis.blade.php ENDPATH**/ ?>