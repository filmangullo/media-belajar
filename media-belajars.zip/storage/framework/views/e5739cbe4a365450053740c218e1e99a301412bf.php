<?php $__env->startSection('courses'); ?>

menu-active

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-white">
    Tugas Panel
</h1>
<p><?php echo e($forum->kelasMataPelajarans['nama']); ?> - <?php echo e($forum->nama); ?></p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.courses')); ?>">Courses</a>
        <i class="lnr lnr-arrow-right"></i>
        <a
            href="<?php echo e(route('show.courses', $forum->kelasMataPelajarans['id'] )); ?>"><?php echo e($forum->kelasMataPelajarans['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.pertemuan', $forum->id )); ?>"><?php echo e($forum['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.tugaspanel', $forum->id )); ?>">Tugas Panel</a>
    </span>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- Start Align Area -->
<div class="whole-wrap">
    <div class="container">
        <div class="section-top-border">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(auth::user()->role == 'pengajar'): ?>
            <div class="row mb-10">
                <div class="col-md-6 text-center">
                    <a href="<?php echo e(route('create_tugas.tugaspanel', $forum->id)); ?>"
                        class="primary-btn text-center openPopup">Buat Tugas Baru</a>
                </div>
                <div class="col-md-6 text-center">
                    <a href="javascript:void(0);" data-href="<?php echo e(route('open_file.tugaspanel', $forum->id)); ?>"
                        class="primary-btn text-center openPopup">Upload Tugas Baru</a>
                </div>
                <div class="col-md-12 text-center">
                    ||||||||||||||||||||||||||||||||||||||||||||||
                </div>
                <div class="col-md-4 text-center">
                    <form action="<?php echo e(route('update_panel.tugaspanel', $panel->id )); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <label for="cars">Status Tugas : <?php echo e($panel->open_tugas == true ? "Open" : "Close"); ?></label>
                        <select id="open_tugas" name="open_tugas" class="form-control">
                            <option value="true" <?php echo e($panel->open_tugas == true ? "selected" : ""); ?>>Open</option>
                            <option value="false" <?php echo e($panel->open_tugas == false ? "selected" : ""); ?>>Close</option>
                        </select>
                </div>
                <div class="col-md-4 text-center">
                    <label for="cars">Deadline:
                        <?php echo e($panel->deadline == null ? "Belum set" :  date('d F Y - H:i a',strtotime($panel->deadline))); ?></label>
                    <input type="datetime-local" id="open_soal" name="deadline" value="<?php echo e($panel->deadline); ?>"
                        class="form-control">
                </div>
                <div class="col-md-4 text-center">
                    <label for="cars">Save Setelah Melakukan Perubahan..!</label>
                    <button type="submit" class="genric-btn primary btn-block medium radius form-control ">Save</button>
                </div>
                </form>
            </div>

            <?php endif; ?>

            <h3 class="mb-10">Soal Kuis</h3>
            <div class="row">
                <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-12">

                    <?php if($value->tipe == "TXT"): ?>
                    <div class="row mb-10">
                        <div class="col-md-2 offset-md-8">
                            <a href="<?php echo e(route('edit_tugas.tugaspanel', $value->id )); ?>"
                                class="genric-btn info btn-block text-center openPopup">Edit</a>
                        </div>
                        <div class="col-md-2">
                            <form action="<?php echo e(route('destroy_tugas.tugaspanel', $value->id )); ?>" method="post">
                                <input class="genric-btn danger btn-block text-center" type="submit" value="Delete"
                                    onclick="return confirm('Are you sure you want to delete this item?');" />
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>

                    <blockquote class="generic-blockquote">
                        <p><?php echo $value->tugas; ?></p>
                        <p><?php echo e($value->keterangan); ?></p>
                    </blockquote>
                    <?php elseif($value->tipe == "FLE"): ?>
                    <div class="row mb-10">
                        <div class="col-md-2 offset-md-8">
                            <a href="javascript:void(0);" data-href="<?php echo e(route('change_file.tugaspanel', $value->id)); ?>"
                                class="genric-btn info btn-block text-center openPopup">Edit</a>
                        </div>
                        <div class="col-md-2">
                            <form action="<?php echo e(route('destroy_file.tugaspanel', $value->id )); ?>" method="post">
                                <input class="genric-btn danger btn-block text-center" type="submit" value="Delete"
                                    onclick="return confirm('Are you sure you want to delete this item?');" />
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>

                    <blockquote class="generic-blockquote">
                        <p><a href="<?php echo e(route('download.tugasonpanel', $value->id)); ?>"><i
                                    class="lnr lnr-download"></i>&nbsp;Download</a>&nbsp;
                            <?php echo e($value->nama); ?>. &nbsp;</p>
                        <p><?php echo e($value->keterangan); ?></p>
                    </blockquote>
                    <?php endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- End Align Area -->
    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.openPopup').on('click', function () {
                var dataURL = $(this).attr('data-href');
                $('.modal-dialog').load(dataURL, function () {
                    $('#myModal').modal({
                        show: true
                    });
                });
            });
        });

    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/tugas/tugas_panel.blade.php ENDPATH**/ ?>