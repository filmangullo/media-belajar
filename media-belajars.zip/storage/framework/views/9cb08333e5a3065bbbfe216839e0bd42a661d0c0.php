<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Dasboard</h1>
    <p class="mb-4">Data Ini bertujuan untuk melihat berapa banyak Kelas yang online yang dibuka dalam setiap instansi.
    </p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-10">
                            <h6 class="m-0 font-weight-bold text-primary">Data Instansi</h6>
                    </div>
                    <div class="col-md-2">
                            <a href="<?php echo e(route('adm.instansi.create')); ?>" type="button" class="btn btn-success btn-sm btn-block">New Instansi</a>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Total Kelas</th>
                            <th>Kelas Aktif</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Total Kelas</th>
                            <th>Kelas Aktif</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $instansis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><a href="<?php echo e(route('adm.kelasmatapelajaran.index', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                                <td><?php echo str_limit ($item->alamat, 30, ' ...'); ?></td>
                                <td>27</td>
                                <td>2011/01/25</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- Page level custom scripts -->
<script src="<?php echo e(URL::asset('admins/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/admins/dashboard.blade.php ENDPATH**/ ?>