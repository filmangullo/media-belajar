<?php $__env->startSection('courses'); ?>

menu-active

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<h1 class="text-white">
    Kelas Online
</h1>
<p>Selamat datang, Silahkan mengikuti forum atau pertuam secara Online, jangan Ketinggalan dalam diskusi.</p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.courses')); ?>">Courses</a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('show.courses', $kelas->id )); ?>"><?php echo e($kelas->nama); ?></a>
    </span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Courses Area -->
<section class="courses-area section-gap">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 about-right">
                <h1>
                    <?php echo e($kelas->nama); ?>

                </h1>
                <div class="wow fadeIn" data-wow-duration="1s">
                    <p>
                       <?php echo e($kelas->keterangan); ?>

                    </p>
                </div>
                <?php if(auth::user()->role == 'pengajar'): ?>

                    <a href="<?php echo e(route('createForum.courses', $kelas->id)); ?>" class="primary-btn white">Forum Baru</a>
                <?php endif; ?>

            </div>
            <div class="offset-lg-1 col-lg-6">
                <div class="courses-right">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <ul class="courses-list">
                                <?php $__currentLoopData = $forum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a class="wow fadeInLeft" href="<?php echo e(route('index.pertemuan', $item->id)); ?>" data-wow-duration="1s"
                                        data-wow-delay=".1s">
                                        <i class="fa fa-book"></i> <?php echo e($item->nama); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Courses Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/forum/forum.blade.php ENDPATH**/ ?>