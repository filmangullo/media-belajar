<?php $__env->startSection('panduan'); ?>

menu-active

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<h1 class="text-white">
    Panduan
</h1>
<p>Dalam pengajaran modern, mungkin tidak ada satu pun lompatan ke depan selain pembangunan dan memberikan cara yang inovasi.</p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('panduan.index')); ?>">Panduan</a>
    </span>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/panduan/index.blade.php ENDPATH**/ ?>