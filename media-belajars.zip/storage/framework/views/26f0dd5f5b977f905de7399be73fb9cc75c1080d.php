<div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title">Edit Diskusi</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <form action="<?php echo e(route('update.diskusi', $query->id )); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="modal-body">
        <textarea id="diskusi" name="diskusi" rows="4" style="width:100%" required><?php echo e($query->diskusi); ?></textarea>
      </form>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Save changes</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
</div>
<?php /**PATH /var/www/media-belajar/resources/views/webs/pertemuan/diskusi_edit.blade.php ENDPATH**/ ?>