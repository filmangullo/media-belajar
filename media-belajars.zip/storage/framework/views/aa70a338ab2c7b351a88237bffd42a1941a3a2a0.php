<?php $__env->startSection('courses'); ?>

menu-active

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-white">
    Daftar Tugas <?php echo e($forum->kelasMataPelajarans['nama']); ?>

</h1>
<p><?php echo e($forum->nama); ?></p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.courses')); ?>">Courses</a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('show.courses', $forum->kelasMataPelajarans['id'] )); ?>"><?php echo e($forum->kelasMataPelajarans['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.pertemuan', $forum->id )); ?>"><?php echo e($forum['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.tugaspelajar', $forum->id )); ?>">Daftar Tugas</a>
    </span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Align Area -->
<div class="whole-wrap">
  <div class="container">
    <div class="section-top-border">
      <table class="table">
        <thead class="thead-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nama</th>
            <th scope="col">Level</th>
            <th scope="col">Tanggal dan Waktu</th>
            <th scope="col">Nilai</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($key+1); ?></th>
                <th><?php echo e($item['nama']); ?></th>
                <th><?php echo e($item['level']); ?></th>
                <th><?php echo e($item['tgl_upload']); ?></th>
                <th><?php echo e($item['tgs_nilai']); ?></th>
                <th><a <?php echo $item['id_tugas'] != null ? 'href="'.route('show.tugaspelajar', $item['id_tugas'] ).'"' : 'disabled'; ?> class="btn btn-info">Show</a></th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/tugas/tugas_pelajar.blade.php ENDPATH**/ ?>