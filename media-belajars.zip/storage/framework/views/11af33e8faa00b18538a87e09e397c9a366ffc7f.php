<?php $__env->startSection('courses'); ?>

menu-active

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    h1,
    h2,
    p,
    a {
        font-family: sans-serif;
        font-weight: normal;
    }

    .jam-digital-malasngoding {
        overflow: hidden;
        width: 289px;
        margin: 20px auto;
        border: 5px solid #efefef;
    }

    .kotak {
        float: left;
        width: 93px;
        height: 80px;
        background-color: #189fff;
    }

    .jam-digital-malasngoding p {
        color: #fff;
        font-size: 36px;
        text-align: center;
        margin-top: 30px;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

<h1 class="text-white">
    <?php echo e($forum->kelasMataPelajarans['nama']); ?>

</h1>
<p><?php echo e($forum->kelasMataPelajarans['keterangan']); ?></p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.courses')); ?>">Courses</a>
        <i class="lnr lnr-arrow-right"></i>
        <a
            href="<?php echo e(route('show.courses', $forum->kelasMataPelajarans['id'] )); ?>"><?php echo e($forum->kelasMataPelajarans['nama']); ?></a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.pertemuan', $forum->id )); ?>"><?php echo e($forum['nama']); ?></a>

    </span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Align Area -->
<div class="whole-wrap">
    <div class="container">
        <div class="section-top-border">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="jam-digital-malasngoding">
                <div class="kotak">
                    <p id="jam"></p>
                </div>
                <div class="kotak">
                    <p id="menit"></p>
                </div>
                <div class="kotak">
                    <p id="detik"></p>
                </div>
            </div>
            <?php if(auth::user()->role == 'pengajar'): ?>
            <div class="row mb-20">
                <div class="col-md-2">
                    <a href="javascript:void(0);" data-href="<?php echo e(route('create.deskripsi', $forum->id)); ?>"
                        class="primary-btn btn-block text-center openPopup">Add Deskripsi</a>
                </div>
                <div class="col-md-2">
                    <a href="javascript:void(0);" data-href="<?php echo e(route('create.file', $forum->id)); ?>"
                        class="primary-btn btn-block text-center openPopup">Add File</a>
                </div>
                <div class="col-md-2">
                    <a href="javascript:void(0);" data-href="<?php echo e(route('create.video', $forum->id)); ?>"
                        class="primary-btn btn-block text-center openPopup">Add Video</a>
                </div>
                <div class="col-md-2">
                    <a href="javascript:void(0);" data-href="<?php echo e(route('create.link', $forum->id)); ?>"
                        class="primary-btn btn-block text-center openPopup">Add Link</a>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(route('index.kuispanel', $forum->id)); ?>" class="primary-btn btn-block text-center ">Kuis
                        Panel</a>
                </div>

                <div class="col-md-2">
                    <a href="<?php echo e(route('index.tugaspanel', $forum->id)); ?>"
                        class="primary-btn btn-block text-center ">Tugas Panel</a>
                </div>
            </div>
            <div class="row mb-20">
                <div class="col-md-2 offset-md-8">
                    <a href="<?php echo e(route('index.kuisnilai', $forum->id)); ?>" class="primary-btn btn-block text-center ">Nilai
                        Kuis</a>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(route('index.tugaspelajar', $forum->id)); ?>"
                        class="primary-btn btn-block text-center ">Nilai Tugas</a>
                </div>
            </div>
            <div class="row mb-20">
                <div class="col-md-2 offset-md-8">
                    <a href="javascript:void(0)" data-href="<?php echo e(route('editForum.courses', $forum->id )); ?>"
                        class="genric-btn info btn-block text-center openPopup">Edit</a>
                </div>
                <div class="col-md-2">
                    <form action="<?php echo e(route('destroyForum.courses', $forum->id )); ?>" method="post">
                        <input class="genric-btn danger btn-block text-center" type="submit" value="Delete"
                            onclick="return confirm('Are you sure you want to delete this item?');" />
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <div class="row">


                <div class="col-lg-8 col-md-8">
                    
                    
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(auth::user()->role == 'pengajar'): ?>
                            <form action="<?php echo e(route('destroy.video', $value->id)); ?>"
                                class="float-right" method="post">
                                <button  type="submit" class="genric-btn danger btn-block text-center"
                                    onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php endif; ?>
                        <?php if($value->type == 'link'): ?>
                            <iframe width="100%" height="400" src="<?php echo e($value->video); ?>" webkitallowfullscreen="1" mozallowfullscreen="1" allowfullscreen="1"></iframe>
                        <?php else: ?>
                            <video width="100%" height="345" controls>
                                <source src="<?php echo e(asset('storage/'.$value->video)); ?>" type="video/mp4">
                                <source src="<?php echo e(asset('storage/'.$value->video)); ?>" type="video/ogg">
                                Your browser does not support the video tag.
                            </video>
                        <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <h4 class="mb-10">Deskripsi / Quotes</h4>
                    <div class="wow fadeIn" data-wow-duration="1s">
                        <?php $__currentLoopData = $deskripsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($value->deskripsi); ?>. &nbsp;
                            <?php if(auth::user()->role == 'pengajar'): ?>
                                <a href="javascript:void(0)" data-href="<?php echo e(route('edit.deskripsi', $value->id)); ?>"
                                class="openPopup"><i class="lnr lnr-pencil"></i></a>

                                <a href="<?php echo e(route('destroy.deskripsi', $value->id)); ?>" onclick="return confirm('Are you sure you want to delete this item?');"
                                    class="openPopup"><i class="lnr lnr-trash" style="color: red"></i></a>
                            <?php endif; ?>
                        </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="wow fadeIn" data-wow-duration="1s">
                        <?php if($file != null): ?>
                            <h4 class="mb-10">File Materi</h4>
                        <?php endif; ?>
                        <?php $__currentLoopData = $file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><a href="<?php echo e(route('download.file', $value->id)); ?>"><i
                                    class="lnr lnr-download"></i>&nbsp;Download</a>&nbsp;
                            <?php echo e($value->name); ?>. &nbsp;
                            <?php if(auth::user()->role == 'pengajar'): ?>
                            <a href="<?php echo e(route('destroy.file', $value->id)); ?>" rel="noopener noreferrer"><i
                                    class="lnr lnr-trash"></i></a>
                            <?php endif; ?>
                        </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="comments-area" id="diskusiShow">
                        <h4 class="mb-30">Forum Diskusi</h4>

                        <!--List Diskusi -->
                        <?php $__currentLoopData = $diskusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="comment-list right-padding">
                            <div class="single-comment justify-content-between d-flex">
                                <div class="user justify-content-between d-flex">
                                    <div class="thumb">
                                        <?php if($value->users['avatar'] != null ): ?>
                                        <img src="<?php echo e(URL::asset('storage/'.$value->users['avatar'])); ?>" alt=""
                                            width="40" style="border-radius: 50%;">
                                        <?php else: ?>
                                        <img src="<?php echo e(asset($value->users['role'].'.png')); ?>" alt="" width="40">
                                        <?php endif; ?>
                                    </div>
                                    <div class="desc">
                                        <h5><a href="#"><?php echo e($value->users['name']); ?></a></h5>
                                        <p class="date"><?php echo e(date_format($value->created_at, "F d, Y" )); ?> at
                                            <?php echo e(date_format($value->created_at, "H:i:s" )); ?> </p>
                                        <p class="comment"><?php echo e($value->diskusi); ?> 
                                            <?php if($value->extension_file != null &&  $value->extension_file ==  'jpeg' || 'png' || 'jpeg'): ?>
                                            <img src="<?php echo e(asset('storage/'.$value->file)); ?>" alt="" width="90%">
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="reply-btn" style="position: absolute; margin-left:62%;">
                                    <?php if(Auth::user()->id == $value->user_id): ?>
                                    <a href="javascript:void(0);" data-href="<?php echo e(route('delete.diskusi', $value->id)); ?>"
                                        class="float-right openPopup comment"
                                        style="color:red;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Delete</a>

                                    <a href="javascript:void(0);" data-href="<?php echo e(route('edit.diskusi', $value->id)); ?>"
                                        class="float-right openPopup comment"
                                        style="color:aqua;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Edit</a>
                                    <?php endif; ?>
                                    <a href="javascript:void(0);"
                                        data-href="<?php echo e(route('create.diskusicomment', $value->id)); ?>"
                                        class="float-right openPopup comment" style="color:blue;">Comment</a>
                                </div>
                            </div>
                        </div>
                        <!-- List Coment Diskusi -->
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->id == $comment->forum_diskusi_id): ?>
                        <div class="comment-list left-padding">
                            <div class="single-comment justify-content-between d-flex">
                                <div class="user justify-content-between d-flex">
                                    <div class="thumb">
                                        <?php if($comment->users['avatar'] != null ): ?>
                                        <img src="<?php echo e(URL::asset('storage/'.$comment->users['avatar'])); ?>" alt=""
                                            width="40" style="border-radius: 50%;">
                                        <?php else: ?>
                                        <img src="<?php echo e(asset($comment->users['role'].'.png')); ?>" alt="" width="40">
                                        <?php endif; ?>

                                    </div>
                                    <div class="desc">
                                        <h5><a href="#"><?php echo e($comment->users['name']); ?></a></h5>
                                        <p class="date"><?php echo e(date_format($comment->created_at, "F d, Y" )); ?> at
                                            <?php echo e(date_format($comment->created_at, "H:i:s" )); ?></p>
                                        <p class="comment">
                                            <?php echo e($comment->comment); ?>

                                        </p>
                                    </div>
                                </div>
                                <div class="reply-btn">
                                    <?php if(Auth::user()->id == $comment->user_id): ?>
                                    <form action="<?php echo e(route('destroy.diskusicomment', $comment->id )); ?>"
                                        class="float-right" method="post">
                                        <input class="text-center" type="submit"
                                            value="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Delete"
                                            onclick="return confirm('Are you sure you want to delete this item?');"
                                            style="color:red; border:none; background-color: transparent" />
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                    </form>

                                    <a href="javascript:void(0);"
                                        data-href="<?php echo e(route('edit.diskusicomment', $comment->id)); ?>"
                                        class="float-right openPopup" style="color:aqua;">Edit</a>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- End List Comment Diskusi -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- End List Diskusi -->

                    </div>

                    <!-- Diskusi Form -->
                    <?php echo $__env->make('webs.pertemuan.diskusi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- End Diskusi Form -->

                </div>
                <div class="col-lg-3 col-md-4 mt-sm-30">
                    <div class="single-element-widget mt-30 ">
                        <?php if($panel->open_kuis == true || auth::user()->role == 'pengajar'): ?>
                        <?php if($panel->open_kuis == true): ?>
                        <p>Kuis Telah dibuka,..?</p>
                        <?php elseif($panel->open_kuis == false): ?>
                        <p>Kuis Belum dibuka,..!</p>
                        <?php endif; ?>
                        <a href="<?php echo e(route('index.kuis', $forum->id)); ?>"
                            class="genric-btn btn-block success circle arrow text-center">Mulai Kuis<span
                                class="lnr lnr-arrow-right"></span></a>
                        <?php endif; ?>
                    </div>

                    <div class="single-element-widget mt-30 ">
                        <?php if($panelTugas->open_tugas == true || auth::user()->role == 'pengajar'): ?>
                        <?php if($panelTugas->open_tugas == true ): ?>
                        <p>Tugas Telah dibuka,..?</p>
                        <p>Deadline :<?php echo e(date('d M Y - H:i a',strtotime($panelTugas->deadline))); ?></p>
                        <?php elseif($panelTugas->open_tugas == false): ?>
                        <p>Tugas Belum dibuka,..!</p>
                        <?php endif; ?>
                        <?php if(strtotime(date('Y/m/d H:i:s')) <= strtotime($panelTugas->deadline)): ?>
                            <a href="<?php echo e(route('index.tugas', $forum->id)); ?>"
                                class="genric-btn btn-block info circle arrow text-center">Kerjakan Tugas<span
                                    class="lnr lnr-arrow-right"></span></a>
                            <?php endif; ?>
                            <?php endif; ?>
                    </div>
                    <div class="single-element-widget mt-30 ">
                        <h3 class="mb-30 ">Participant</h3>
                        <?php $__currentLoopData = $participant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="switch-wrap d-flex justify-content-between ">
                            <p><?php echo e($key+1); ?>. <a href="<?php echo e(route('index.profil')); ?>"
                                    onclick="event.preventDefault();
                                document.getElementById('profil-form_<?php echo e($value->users->id); ?>').submit();"><?php echo e($value->users['name']); ?></a></p>
                            <form id="profil-form_<?php echo e($value->users->id); ?>" action="<?php echo e(route('index.profil')); ?>"
                                method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e($value->users->id); ?>">
                            </form>




                            <?php if(Cache::has('user-is-online-' . $value->users['id'])): ?>
                            <div class="primary-checkbox ">
                                <?php echo $value->users['role'] == 'pengajar' ? '<span
                                    class="lnr lnr-briefcase text-success"></span>' :
                                '<span class="lnr lnr-graduation-hat text-success"></span>'; ?>

                                <?php else: ?>
                                <?php echo $value->users['role'] == 'pengajar' ? '<span
                                    class="lnr lnr-briefcase text-secondary"></span>' :
                                '<span class="lnr lnr-graduation-hat text-secondary"></span>'; ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Align Area -->
<?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    window.setTimeout("waktu()", 1000);

    function waktu() {
        var waktu = new Date();
        setTimeout("waktu()", 1000);
        document.getElementById("jam").innerHTML = waktu.getHours();
        document.getElementById("menit").innerHTML = waktu.getMinutes();
        document.getElementById("detik").innerHTML = waktu.getSeconds();
    }

    // Fungsi untuk menampilkan Nama File jika di Upload pada AddFile
    function myFile() {
        var xfile = document.getElementById("fileX").files[0].name;
        document.getElementById("nameFileX").innerHTML = xfile;
    }

</script>

<script>
    $(document).ready(function () {
        $('.openPopup').on('click', function () {
            var dataURL = $(this).attr('data-href');
            $('.modal-dialog').load(dataURL, function () {
                $('#myModal').modal({
                    show: true
                });
            });
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/pertemuan/pertemuan.blade.php ENDPATH**/ ?>