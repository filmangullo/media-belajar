<div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Comments</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('store.diskusicomment', $query->id )); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <div class="modal-body">
          <p><?php echo e($query->diskusi); ?></p>
          <textarea id="deskripsi" name="comment" rows="4" required style="width:100%" ></textarea>
        </form>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Save</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
</div>
<?php /**PATH /var/www/media-belajar/resources/views/webs/pertemuan/comment.blade.php ENDPATH**/ ?>