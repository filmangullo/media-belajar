<?php $__env->startSection('header'); ?>
<h1 class="text-white">
    Pencarian
</h1>
<p>Dalam pengajaran modern, mungkin tidak ada satu pun lompatan ke depan selain pembangunan dan memberikan cara yang inovasi.</p>
<div class="link-nav">
    <span class="box">
        <a href="/">Home </a>
        <i class="lnr lnr-arrow-right"></i>
        <a href="<?php echo e(route('index.courses')); ?>">Hasil Pencarian Pembelajaran</a>
    </span>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--Start Feature Area -->
<section class="feature-area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
              <div class="input-wrap">
    						<form action="<?php echo e(route('index.search')); ?>" class="form-box d-flex justify-content-between" method="get" enctype="multipart/form-data">
    							<input type="text" placeholder="Cari Kelas" class="form-control" name="search">
    							<button type="submit" class="btn search-btn">Cari</button>
    						</form>
    					</div>
                <div class="section-title text-center">
                    <h1>Kelas / Forum</h1>
                    <p>
                        Selamat mengikuti forum pada kelas pembelajaran, semoga anda sukses dalam forum yang disediakan
                    </p>
                      <?php echo $alert; ?>

                    <div class="button-group-area mt-10 text-center">
                      <?php if(auth()->guard()->check()): ?>
              				<?php if(Auth::user()->role == 'pengajar'): ?>
              				<a href="<?php echo e(route('create.courses')); ?>" class="genric-btn primary circle arrow">Tambah Kelas Baru<span class="lnr lnr-database"></span></a>
                      <?php endif; ?>
                      <?php endif; ?>
              			</div>
                </div>

            </div>
        </div>
        <div class="feature-inner row">
            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                  <?php if(auth()->guard()->check()): ?>
                  <?php if( Auth::user()->id == $item->user_id ): ?>
                    <form action="<?php echo e(route('destroy.courses', $item->id )); ?>" method="post">
                        <input class="genric-btn danger-border float-right" type="submit" value="Delete" onclick="return confirm('Are you sure you want to delete this item?');" />
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                  <?php endif; ?>
                  <?php endif; ?>


                    <div class="feature-item">
                        <p>
                          <i class="fa fa-book"></i>&nbsp;<?php echo e($item->users['name']); ?>

                        </p>
                        <h4><a href="<?php echo e(route('show.courses', $item->id)); ?>"><?php echo e($item->nama); ?></a></h4>
                        <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
                            <p>
                                <?php echo e(substr($item->keterangan,0,60).'...'); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<!-- End Feature Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/media-belajar/resources/views/webs/beranda/search.blade.php ENDPATH**/ ?>